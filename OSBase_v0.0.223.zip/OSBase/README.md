# OSBase
OSBase CS2 plugin to further control CS2 servers like 

1. Apply config to when matches starts
2. Apply different config when matches ends
 
